import zmq, time
context = zmq.Context()

s = context.socket(zmq.PUB) #create a publisher socket

#p = "tcp://*":"+ PORT #How and where to communicate 

s.bind("tcp://*:5555") #bind socket to the address

while True:
    time.sleep(5)  #Wait every 5 seconds
    s.send_string("TIME"+ str(time.asctime())) #Publish the current time 
